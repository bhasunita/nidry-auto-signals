# NIFTY Auto Signals — Render version

This is the no-API-key hosted version.

## What it does
- Fetches NIFTY 50 (^NSEI) 5-minute data server-side
- Avoids Android Chrome CORS problems
- Recalculates every 15 seconds in the browser
- Shows BUY / SELL / NO TRADE
- Shows Buy Above, Sell Below, Stop Loss, Target 1, Target 2
- Uses EMA 9/21, RSI 14, Supertrend, ATR and a 3-candle breakout
- Contains NO order-placement code

## Deploy on Render from Android

1. Create a GitHub account if you do not already have one.
2. Create a new GitHub repository, e.g. `nifty-auto-signals`.
3. Upload these files from this ZIP to that repository:
   - app.py
   - requirements.txt
   - render.yaml
4. Sign in to Render.com with GitHub.
5. Tap **New +** → **Blueprint**.
6. Select the repository you created.
7. Render reads `render.yaml`; tap **Apply** / **Deploy**.
8. Wait for the build to finish.
9. Render gives you a URL like:
   `https://nifty-auto-signals.onrender.com`
10. Open that URL in Chrome on Android and optionally choose **Add to Home screen**.

## Notes
- Render free services may sleep when idle, so the first open after inactivity can take a little time.
- Yahoo/public data can be delayed or temporarily unavailable.
- Signals are for decision support only and can fail.
